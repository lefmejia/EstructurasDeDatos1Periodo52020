#include <iostream>
#include <string.h>
#include "tapio/rlutil.h"
#include <stdlib.h>
#include <stdio.h>
#include <thread>
#include <termios.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/time.h>
#include <vector>

using namespace std;

int nScreenWidth = 80;			
int nScreenHeight = 30;	

string tetromino[7];
int boardW = 12;
int boardH = 18;
unsigned char *pField = nullptr;

int Rotate(int px, int py, int r)
{
	int pi = 0;
	switch (r % 4)
	{
	case 0: // 0 degrees			// 0  1  2  3
		pi = py * 4 + px;			// 4  5  6  7
		break;						// 8  9 10 11
									//12 13 14 15

	case 1: // 90 degrees			//12  8  4  0
		pi = 12 + py - (px * 4);	//13  9  5  1
		break;						//14 10  6  2
									//15 11  7  3

	case 2: // 180 degrees			//15 14 13 12
		pi = 15 - (py * 4) - px;	//11 10  9  8
		break;						// 7  6  5  4
									// 3  2  1  0

	case 3: // 270 degrees			// 3  7 11 15
		pi = 3 - py + (px * 4);		// 2  6 10 14
		break;						// 1  5  9 13
	}								// 0  4  8 12

	return pi;
}

bool DoesPieceFit(int nTetromino, int nRotation, int nPosX, int nPosY)
{
	// All Field cells >0 are occupied
	for (int px = 0; px < 4; px++)
		for (int py = 0; py < 4; py++)
		{
			// Get index into piece
			int pi = Rotate(px, py, nRotation);

			// Get index into field
			int fi = (nPosY + py) * boardW + (nPosX + px);

			// Check that test is in bounds. Note out of bounds does
			// not necessarily mean a fail, as the long vertical piece
			// can have cells that lie outside the boundary, so we'll
			// just ignore them
			if (nPosX + px >= 0 && nPosX + px < boardW)
			{
				if (nPosY + py >= 0 && nPosY + py < boardH)
				{
					// In Bounds so do collision check
					if (tetromino[nTetromino][pi] != L'.' && pField[fi] != 0)
						return false; // fail on first hit
				}
			}
		}

	return true;
}

int main()
{
    wchar_t *screen = new wchar_t[nScreenWidth*nScreenHeight];
    char* newscreen = new char[nScreenWidth*nScreenHeight];
    for(int i=0; i< nScreenWidth*nScreenHeight; i++)
        {
            newscreen[i] = ' ';
        }

    tetromino[0].append("..X.");
    tetromino[0].append("..X.");
    tetromino[0].append("..X.");
    tetromino[0].append("..X.");

    tetromino[1].append("....");
    tetromino[1].append(".XX.");
    tetromino[1].append(".XX.");
    tetromino[1].append("....");

    tetromino[2].append("....");
    tetromino[2].append("..X.");
    tetromino[2].append(".XX.");
    tetromino[2].append(".X..");

    tetromino[3].append("....");
    tetromino[3].append("..X.");
    tetromino[3].append("..XX");
    tetromino[3].append("...X");

    tetromino[4].append("....");
    tetromino[4].append(".XX.");
    tetromino[4].append("..X.");
    tetromino[4].append("..X.");

    tetromino[5].append("....");
    tetromino[5].append("..XX");
    tetromino[5].append("..X.");
    tetromino[5].append("..X.");

    tetromino[6].append("....");
    tetromino[6].append("..X.");
    tetromino[6].append(".XX.");
    tetromino[6].append("..X.");

    pField = new unsigned char[boardW * boardH];
    for(int x = 0; x < boardW; x++)
    {
        for(int y = 0; y < boardH; y++)
        {
            pField[y*boardW + x] = (x==0 || x==boardW - 1 || y == boardH -1)? 9 : 0;

        }
    }

    bool gameover = false;
    bool active = false;
    bool bKey[4];
    int nCurrentPiece = 0;
	int nCurrentRotation = 0;
	int nCurrentX = boardW / 2;
	int nCurrentY = 0;
	int nSpeed = 20;
	int nSpeedCount = 0;
	bool bForceDown = false;
	bool bRotateHold = true;
	int nPieceCount = 0;
	int nScore = 0;
	vector<int> vLines;
    while(!gameover)
    {
        // Timer
        this_thread::sleep_for(50ms);
        nSpeedCount++;
		bForceDown = (nSpeedCount == nSpeed);
        // Input
        
        if(kbhit())
        {
            if(getch() == '\033')
            {
                getch();
                switch(getch()) 
                {
                case 'A': //FLECHA ARRIBA
                    nCurrentRotation += (bRotateHold && DoesPieceFit(nCurrentPiece, nCurrentRotation + 1, nCurrentX, nCurrentY)) ? 1 : 0;
			        bRotateHold = false;
                    active = true;
                break;
                case 'B': //FLECHA ABAJO
                    nCurrentY += (DoesPieceFit(nCurrentPiece, nCurrentRotation, nCurrentX, nCurrentY + 1)) ? 1 : 0;
                break;
                case 'C':  //FLECHA DERECHA
                    nCurrentX += (DoesPieceFit(nCurrentPiece, nCurrentRotation, nCurrentX + 1, nCurrentY)) ? 1 : 0;
                break;
                case 'D': // FLECHA IZQUIERDA
                    nCurrentX -= (DoesPieceFit(nCurrentPiece, nCurrentRotation, nCurrentX - 1, nCurrentY)) ? 1 : 0;
                break;

                default: gameover = true; // ESC
                }
            }
        }

        if(!active)
            bRotateHold = true;
        
        // Logic

        if (bForceDown)
		{
			// Update difficulty every 50 pieces
			nSpeedCount = 0;
			nPieceCount++;
			if (nPieceCount % 50 == 0)
				if (nSpeed >= 10) nSpeed--;
			
			// Test if piece can be moved down
			if (DoesPieceFit(nCurrentPiece, nCurrentRotation, nCurrentX, nCurrentY + 1))
				nCurrentY++; // It can, so do it!
			else
			{
				// It can't! Lock the piece in place
				for (int px = 0; px < 4; px++)
					for (int py = 0; py < 4; py++)
						if (tetromino[nCurrentPiece][Rotate(px, py, nCurrentRotation)] != L'.')
							pField[(nCurrentY + py) * boardW + (nCurrentX + px)] = nCurrentPiece + 1;

				// Check for lines
				for (int py = 0; py < 4; py++)
					if(nCurrentY + py < boardH - 1)
					{
						bool bLine = true;
						for (int px = 1; px < boardW - 1; px++)
							bLine &= (pField[(nCurrentY + py) * boardW + px]) != 0;

						if (bLine)
						{
							// Remove Line, set to =
							for (int px = 1; px < boardW - 1; px++)
								pField[(nCurrentY + py) * boardW + px] = 8;
							vLines.push_back(nCurrentY + py);
						}						
					}

				nScore += 25;
				if(!vLines.empty())	nScore += (1 << vLines.size()) * 100;

				// Pick New Piece
				nCurrentX = boardW / 2;
				nCurrentY = 0;
				nCurrentRotation = 0;
				nCurrentPiece = rand() % 7;

				// If piece does not fit straight away, game over!
				gameover = !DoesPieceFit(nCurrentPiece, nCurrentRotation, nCurrentX, nCurrentY);
			}
		}

        // Output
        rlutil::cls();
        for (int x = 0; x < boardW; x++)
			for (int y = 0; y < boardH; y++)
				newscreen[(y + 2)*nScreenWidth + (x + 2)] = " ABCDEFG=#"[pField[y*boardW + x]];

        

        for (int px = 0; px < 4; px++)
			for (int py = 0; py < 4; py++)
				if (tetromino[nCurrentPiece][Rotate(px, py, nCurrentRotation)] != '.')
					newscreen[(nCurrentY + py + 2)*nScreenWidth + (nCurrentX + px + 2)] = nCurrentPiece + 65;


        //printf(&newscreen[2 * nScreenWidth + boardW + 6], 16, "SCORE: %8d", nScore);

        if (!vLines.empty())
		{
			// Display Frame (cheekily to draw lines)
			for(int i=0; i < nScreenWidth*nScreenHeight; i++)
            {
                if(i%nScreenWidth==0)
                    cout<<"\n";

                cout<<newscreen[i];
            }
			this_thread::sleep_for(400ms); // Delay a bit

			for (auto &v : vLines)
				for (int px = 1; px < boardW - 1; px++)
				{
					for (int py = v; py > 0; py--)
						pField[py * boardW + px] = pField[(py - 1) * boardW + px];
					pField[px] = 0;
				}

			vLines.clear();
		}

        for(int i=0; i < nScreenWidth*nScreenHeight; i++)
        {
            if(i%nScreenWidth==0)
                cout<<"\n";

            cout<<newscreen[i];
        }
        active = false;
    }
    cout << "Game Over!! Score:" << nScore << endl;
    return 0;
}